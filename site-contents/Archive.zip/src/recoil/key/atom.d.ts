declare const keyArnAtom: any;
export default keyArnAtom;
