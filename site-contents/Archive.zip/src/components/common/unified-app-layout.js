"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedAppLayout = void 0;
const react_1 = require("react");
const components_1 = require("@cloudscape-design/components");
const react_router_dom_1 = require("react-router-dom");
const key_svg_1 = require("../../assets/images/key.svg");
const UnifiedAppLayout = ({ content }) => {
    const navigate = (0, react_router_dom_1.useNavigate)();
    const onEncryptionClick = (0, react_1.useCallback)(() => {
        navigate('/encryption');
    }, [navigate]);
    const onDecryptionClick = (0, react_1.useCallback)(() => {
        navigate('/decryption');
    }, [navigate]);
    return (<components_1.AppLayout content={<components_1.ContentLayout header={<react_router_dom_1.Link to="/" style={{ textDecoration: 'none' }}>
              <components_1.Box variant="div" margin={{ top: "l" }}>
                
                <components_1.Header variant="h1">
                  <span className="key-icon">
                    <key_svg_1.ReactComponent />
                  </span>
                  {"KMS Workshop"}
                </components_1.Header>
              </components_1.Box>
            </react_router_dom_1.Link>}>
          <components_1.SpaceBetween size="m">
          <components_1.Container>
            <components_1.Grid gridDefinition={[{ colspan: 6 }, { colspan: 6 }]}>
              <components_1.Box textAlign='center'>
                <components_1.Button variant="primary" onClick={onEncryptionClick}>
                  Encryption
                </components_1.Button>
              </components_1.Box>
              <components_1.Box textAlign='center'>
                <components_1.Button variant="primary" onClick={onDecryptionClick}>
                  Decryption
                </components_1.Button>
              </components_1.Box>
            </components_1.Grid>
          </components_1.Container>
          {content}
          </components_1.SpaceBetween>
        </components_1.ContentLayout>} navigationHide={true} toolsHide={true}/>);
};
exports.UnifiedAppLayout = UnifiedAppLayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidW5pZmllZC1hcHAtbGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidW5pZmllZC1hcHAtbGF5b3V0LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxpQ0FBb0M7QUFDcEMsOERBU3VDO0FBQ3ZDLHVEQUFxRDtBQUVyRCx5REFBd0U7QUFNakUsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLEVBQUMsT0FBTyxFQUF3QixFQUFFLEVBQUU7SUFDbkUsTUFBTSxRQUFRLEdBQUcsSUFBQSw4QkFBVyxHQUFFLENBQUM7SUFFL0IsTUFBTSxpQkFBaUIsR0FBRyxJQUFBLG1CQUFXLEVBQUMsR0FBRyxFQUFFO1FBQ3pDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQixDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRWYsTUFBTSxpQkFBaUIsR0FBRyxJQUFBLG1CQUFXLEVBQUMsR0FBRyxFQUFFO1FBQ3pDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUMxQixDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRWYsT0FBTyxDQUNMLENBQUMsc0JBQVMsQ0FDUixPQUFPLENBQUMsQ0FDTixDQUFDLDBCQUFhLENBQ1osTUFBTSxDQUFDLENBQ0wsQ0FBQyx1QkFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FDN0M7Y0FBQSxDQUFDLGdCQUFHLENBQ0YsT0FBTyxDQUFDLEtBQUssQ0FDYixNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUdyQjs7Z0JBQUEsQ0FBQyxtQkFBTSxDQUNMLE9BQU8sQ0FBQyxJQUFJLENBRVo7a0JBQUEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FDeEI7b0JBQUEsQ0FBQyx3QkFBTyxDQUFDLEFBQUQsRUFDVjtrQkFBQSxFQUFFLElBQUksQ0FDTjtrQkFBQSxDQUFDLGNBQWMsQ0FDakI7Z0JBQUEsRUFBRSxtQkFBTSxDQUNWO2NBQUEsRUFBRSxnQkFBRyxDQUNQO1lBQUEsRUFBRSx1QkFBSSxDQUNSLENBQUMsQ0FFRDtVQUFBLENBQUMseUJBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUN0QjtVQUFBLENBQUMsc0JBQVMsQ0FDUjtZQUFBLENBQUMsaUJBQUksQ0FDSCxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FFakQ7Y0FBQSxDQUFDLGdCQUFHLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FDckI7Z0JBQUEsQ0FBQyxtQkFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FDbkQ7O2dCQUNGLEVBQUUsbUJBQU0sQ0FDVjtjQUFBLEVBQUUsZ0JBQUcsQ0FDTDtjQUFBLENBQUMsZ0JBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUNyQjtnQkFBQSxDQUFDLG1CQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUNuRDs7Z0JBQ0YsRUFBRSxtQkFBTSxDQUNWO2NBQUEsRUFBRSxnQkFBRyxDQUNQO1lBQUEsRUFBRSxpQkFBSSxDQUNSO1VBQUEsRUFBRSxzQkFBUyxDQUNYO1VBQUEsQ0FBQyxPQUFPLENBQ1I7VUFBQSxFQUFFLHlCQUFZLENBQ2hCO1FBQUEsRUFBRSwwQkFBYSxDQUNqQixDQUFDLENBQ0QsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQ3JCLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUNoQixDQUNILENBQUM7QUFDSixDQUFDLENBQUE7QUEzRFksUUFBQSxnQkFBZ0Isb0JBMkQ1QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIEFwcExheW91dCxcbiAgQm94LFxuICBCdXR0b24sXG4gIENvbnRhaW5lcixcbiAgQ29udGVudExheW91dCxcbiAgR3JpZCxcbiAgSGVhZGVyLFxuICBTcGFjZUJldHdlZW5cbn0gZnJvbSAnQGNsb3Vkc2NhcGUtZGVzaWduL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuaW1wb3J0IHsgUmVhY3RDb21wb25lbnQgYXMgS2V5SWNvbiB9IGZyb20gJy4uLy4uL2Fzc2V0cy9pbWFnZXMva2V5LnN2Zyc7XG5cbmV4cG9ydCB0eXBlIFVuaWZpZWRBcHBMYXlvdXRQcm9wcyA9IHtcbiAgY29udGVudDogSlNYLkVsZW1lbnRcbn1cblxuZXhwb3J0IGNvbnN0IFVuaWZpZWRBcHBMYXlvdXQgPSAoe2NvbnRlbnR9OiBVbmlmaWVkQXBwTGF5b3V0UHJvcHMpID0+IHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIGNvbnN0IG9uRW5jcnlwdGlvbkNsaWNrID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIG5hdmlnYXRlKCcvZW5jcnlwdGlvbicpO1xuICB9LCBbbmF2aWdhdGVdKTtcbiAgXG4gIGNvbnN0IG9uRGVjcnlwdGlvbkNsaWNrID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIG5hdmlnYXRlKCcvZGVjcnlwdGlvbicpO1xuICB9LCBbbmF2aWdhdGVdKTtcblxuICByZXR1cm4gKFxuICAgIDxBcHBMYXlvdXRcbiAgICAgIGNvbnRlbnQ9e1xuICAgICAgICA8Q29udGVudExheW91dFxuICAgICAgICAgIGhlYWRlcj17XG4gICAgICAgICAgICA8TGluayB0bz1cIi9cIiBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH19PlxuICAgICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImRpdlwiXG4gICAgICAgICAgICAgICAgbWFyZ2luPXt7IHRvcDogXCJsXCIgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIDxIZWFkZXJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJoMVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwia2V5LWljb25cIj5cbiAgICAgICAgICAgICAgICAgICAgPEtleUljb24gLz5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtcIktNUyBXb3Jrc2hvcFwifVxuICAgICAgICAgICAgICAgIDwvSGVhZGVyPlxuICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICB9XG4gICAgICAgID5cbiAgICAgICAgICA8U3BhY2VCZXR3ZWVuIHNpemU9XCJtXCI+XG4gICAgICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAgICAgIDxHcmlkXG4gICAgICAgICAgICAgIGdyaWREZWZpbml0aW9uPXtbeyBjb2xzcGFuOiA2IH0sIHsgY29sc3BhbjogNiB9XX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJveCB0ZXh0QWxpZ249J2NlbnRlcic+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIG9uQ2xpY2s9e29uRW5jcnlwdGlvbkNsaWNrfT5cbiAgICAgICAgICAgICAgICAgIEVuY3J5cHRpb25cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgIDxCb3ggdGV4dEFsaWduPSdjZW50ZXInPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInByaW1hcnlcIiBvbkNsaWNrPXtvbkRlY3J5cHRpb25DbGlja30+XG4gICAgICAgICAgICAgICAgICBEZWNyeXB0aW9uXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9HcmlkPlxuICAgICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgICAgIHtjb250ZW50fVxuICAgICAgICAgIDwvU3BhY2VCZXR3ZWVuPlxuICAgICAgICA8L0NvbnRlbnRMYXlvdXQ+XG4gICAgICB9XG4gICAgICBuYXZpZ2F0aW9uSGlkZT17dHJ1ZX1cbiAgICAgIHRvb2xzSGlkZT17dHJ1ZX1cbiAgICAvPlxuICApO1xufVxuIl19