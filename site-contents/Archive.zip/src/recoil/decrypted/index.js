"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const atom_1 = require("./atom");
exports.default = atom_1.default;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGlDQUEwQjtBQUUxQixrQkFBZSxjQUFJLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXRvbSBmcm9tICcuL2F0b20nO1xuXG5leHBvcnQgZGVmYXVsdCBhdG9tO1xuIl19