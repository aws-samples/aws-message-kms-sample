export declare const Decryption: () => any;
