"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Home = void 0;
const components_1 = require("@cloudscape-design/components");
const unified_app_layout_1 = require("../../components/common/unified-app-layout");
require("./style.css");
const Home = () => {
    return (<unified_app_layout_1.UnifiedAppLayout content={<components_1.Container>
          <components_1.Box variant="h1" textAlign="center" margin={{ vertical: 'xxxl' }}>
            Welcome to KMS Workshop ! :)
          </components_1.Box>
        </components_1.Container>}/>);
};
exports.Home = Home;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsOERBQStEO0FBQy9ELG1GQUE4RTtBQUM5RSx1QkFBcUI7QUFFZCxNQUFNLElBQUksR0FBRyxHQUFHLEVBQUU7SUFFdkIsT0FBTyxDQUNMLENBQUMscUNBQWdCLENBQ2YsT0FBTyxDQUFDLENBQ04sQ0FBQyxzQkFBUyxDQUNSO1VBQUEsQ0FBQyxnQkFBRyxDQUNGLE9BQU8sQ0FBQyxJQUFJLENBQ1osU0FBUyxDQUFDLFFBQVEsQ0FDbEIsTUFBTSxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FFN0I7O1VBQ0YsRUFBRSxnQkFBRyxDQUNQO1FBQUEsRUFBRSxzQkFBUyxDQUNiLENBQUMsRUFDRCxDQUNILENBQUM7QUFDSixDQUFDLENBQUE7QUFqQlksUUFBQSxJQUFJLFFBaUJoQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJveCwgQ29udGFpbmVyIH0gZnJvbSAnQGNsb3Vkc2NhcGUtZGVzaWduL2NvbXBvbmVudHMnO1xuaW1wb3J0IHsgVW5pZmllZEFwcExheW91dCB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvY29tbW9uL3VuaWZpZWQtYXBwLWxheW91dCc7XG5pbXBvcnQgJy4vc3R5bGUuY3NzJztcblxuZXhwb3J0IGNvbnN0IEhvbWUgPSAoKSA9PiB7XG5cbiAgcmV0dXJuIChcbiAgICA8VW5pZmllZEFwcExheW91dCBcbiAgICAgIGNvbnRlbnQ9e1xuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJoMVwiXG4gICAgICAgICAgICB0ZXh0QWxpZ249XCJjZW50ZXJcIlxuICAgICAgICAgICAgbWFyZ2luPXt7IHZlcnRpY2FsOiAneHh4bCcgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBXZWxjb21lIHRvIEtNUyBXb3Jrc2hvcCAhIDopXG4gICAgICAgICAgPC9Cb3g+XG4gICAgICAgIDwvQ29udGFpbmVyPlxuICAgICAgfVxuICAgIC8+XG4gICk7XG59XG4iXX0=