import './App.css';
declare const App: () => any;
export default App;
