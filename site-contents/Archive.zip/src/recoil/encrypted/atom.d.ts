export interface EncryptedMessage {
    cipherTextBlob: string;
    encryptedData: string;
}
declare const encryptedMessagesAtom: any;
export default encryptedMessagesAtom;
