"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useEncryptMessage = void 0;
const axios_1 = require("axios");
const react_query_1 = require("react-query");
const useEncryptMessage = (options) => {
    return (0, react_query_1.useMutation)('encryptMessage', async (input) => {
        const { keyId: keyid, message: plainmessage } = input;
        if (!process.env.REACT_PUBLIC_API_URL) {
            return null;
        }
        const { data } = await axios_1.default.post(process.env.REACT_PUBLIC_API_URL + 'encrypt', {
            keyid,
            plainmessage
        });
        // const { data } = await axios.get(
        //   process.env.REACT_PUBLIC_API_URL+'encrypt',
        // );
        return {
            body: {
                cipher_text_blob: 'cipher',
                encrypted_data: 'encrypted_data',
            }
        };
        // return data;
    }, options);
};
exports.useEncryptMessage = useEncryptMessage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlLWVuY3J5cHQtbWVzc2FnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzZS1lbmNyeXB0LW1lc3NhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaUNBQTBCO0FBQzFCLDZDQUE4RDtBQU92RCxNQUFNLGlCQUFpQixHQUFHLENBQUMsT0FBa0UsRUFBRSxFQUFFO0lBQ3RHLE9BQU8sSUFBQSx5QkFBVyxFQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUEwQixFQUFFLEVBQUU7UUFDeEUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxHQUFHLEtBQUssQ0FBQztRQUN0RCxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUNELE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxNQUFNLGVBQUssQ0FBQyxJQUFJLENBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxFQUM1QztZQUNFLEtBQUs7WUFDTCxZQUFZO1NBQ2IsQ0FDRixDQUFDO1FBRUYsb0NBQW9DO1FBQ3BDLGdEQUFnRDtRQUNoRCxLQUFLO1FBRUwsT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixnQkFBZ0IsRUFBRSxRQUFRO2dCQUMxQixjQUFjLEVBQUUsZ0JBQWdCO2FBQ2pDO1NBQ0YsQ0FBQTtRQUNELGVBQWU7SUFDakIsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDO0FBMUJXLFFBQUEsaUJBQWlCLHFCQTBCNUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xuaW1wb3J0IHsgVXNlTXV0YXRpb25PcHRpb25zLCB1c2VNdXRhdGlvbiB9IGZyb20gJ3JlYWN0LXF1ZXJ5JztcblxuaW50ZXJmYWNlIEVuY3J5cHRNZXNzYWdlSW5wdXQge1xuICBrZXlJZDogc3RyaW5nO1xuICBtZXNzYWdlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCB1c2VFbmNyeXB0TWVzc2FnZSA9IChvcHRpb25zOiBVc2VNdXRhdGlvbk9wdGlvbnM8dW5rbm93biwgdW5rbm93biwgRW5jcnlwdE1lc3NhZ2VJbnB1dD4pID0+IHtcbiAgcmV0dXJuIHVzZU11dGF0aW9uKCdlbmNyeXB0TWVzc2FnZScsIGFzeW5jIChpbnB1dDogRW5jcnlwdE1lc3NhZ2VJbnB1dCkgPT4ge1xuICAgIGNvbnN0IHsga2V5SWQ6IGtleWlkLCBtZXNzYWdlOiBwbGFpbm1lc3NhZ2UgfSA9IGlucHV0O1xuICAgIGlmICghcHJvY2Vzcy5lbnYuUkVBQ1RfUFVCTElDX0FQSV9VUkwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGF4aW9zLnBvc3QoXG4gICAgICBwcm9jZXNzLmVudi5SRUFDVF9QVUJMSUNfQVBJX1VSTCArICdlbmNyeXB0JyxcbiAgICAgIHtcbiAgICAgICAga2V5aWQsXG4gICAgICAgIHBsYWlubWVzc2FnZVxuICAgICAgfVxuICAgICk7XG4gICAgXG4gICAgLy8gY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBheGlvcy5nZXQoXG4gICAgLy8gICBwcm9jZXNzLmVudi5SRUFDVF9QVUJMSUNfQVBJX1VSTCsnZW5jcnlwdCcsXG4gICAgLy8gKTtcblxuICAgIHJldHVybiB7XG4gICAgICBib2R5OiB7XG4gICAgICAgIGNpcGhlcl90ZXh0X2Jsb2I6ICdjaXBoZXInLFxuICAgICAgICBlbmNyeXB0ZWRfZGF0YTogJ2VuY3J5cHRlZF9kYXRhJyxcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gcmV0dXJuIGRhdGE7XG4gIH0sIG9wdGlvbnMpO1xufTtcbiJdfQ==