/// <reference types="react" />
export type UnifiedAppLayoutProps = {
    content: JSX.Element;
};
export declare const UnifiedAppLayout: ({ content }: UnifiedAppLayoutProps) => import("react").JSX.Element;
