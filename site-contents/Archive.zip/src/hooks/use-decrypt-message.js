"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useDecryptMessage = void 0;
const axios_1 = require("axios");
const react_query_1 = require("react-query");
const useDecryptMessage = (options) => {
    return (0, react_query_1.useMutation)('decryptMessage', async (input) => {
        if (!process.env.REACT_PUBLIC_API_URL) {
            return null;
        }
        const { cipherTextBlob: cipher_text_blob, encryptedData: encrypted_data } = input;
        const { data } = await axios_1.default.post(process.env.REACT_PUBLIC_API_URL + 'decryption', {
            cipher_text_blob,
            encrypted_data
        });
        // const { data } = await axios.get(
        //   process.env.REACT_PUBLIC_API_URL+'decrypt',
        // );
        return data;
    }, options);
};
exports.useDecryptMessage = useDecryptMessage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlLWRlY3J5cHQtbWVzc2FnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzZS1kZWNyeXB0LW1lc3NhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaUNBQTBCO0FBQzFCLDZDQUE4RDtBQU92RCxNQUFNLGlCQUFpQixHQUFHLENBQUMsT0FBa0UsRUFBRSxFQUFFO0lBQ3RHLE9BQU8sSUFBQSx5QkFBVyxFQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUEwQixFQUFFLEVBQUU7UUFDeEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFDRCxNQUFNLEVBQUUsY0FBYyxFQUFFLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsR0FBRyxLQUFLLENBQUM7UUFDbEYsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sZUFBSyxDQUFDLElBQUksQ0FDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxZQUFZLEVBQy9DO1lBQ0UsZ0JBQWdCO1lBQ2hCLGNBQWM7U0FDZixDQUNGLENBQUM7UUFFRixvQ0FBb0M7UUFDcEMsZ0RBQWdEO1FBQ2hELEtBQUs7UUFDTCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQztBQW5CVyxRQUFBLGlCQUFpQixxQkFtQjVCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcbmltcG9ydCB7IFVzZU11dGF0aW9uT3B0aW9ucywgdXNlTXV0YXRpb24gfSBmcm9tICdyZWFjdC1xdWVyeSc7XG5cbmludGVyZmFjZSBEZWNyeXB0TWVzc2FnZUlucHV0IHtcbiAgY2lwaGVyVGV4dEJsb2I6IHN0cmluZztcbiAgZW5jcnlwdGVkRGF0YTogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgdXNlRGVjcnlwdE1lc3NhZ2UgPSAob3B0aW9uczogVXNlTXV0YXRpb25PcHRpb25zPHVua25vd24sIHVua25vd24sIERlY3J5cHRNZXNzYWdlSW5wdXQ+KSA9PiB7XG4gIHJldHVybiB1c2VNdXRhdGlvbignZGVjcnlwdE1lc3NhZ2UnLCBhc3luYyAoaW5wdXQ6IERlY3J5cHRNZXNzYWdlSW5wdXQpID0+IHtcbiAgICBpZiAoIXByb2Nlc3MuZW52LlJFQUNUX1BVQkxJQ19BUElfVVJMKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgeyBjaXBoZXJUZXh0QmxvYjogY2lwaGVyX3RleHRfYmxvYiwgZW5jcnlwdGVkRGF0YTogZW5jcnlwdGVkX2RhdGEgfSA9IGlucHV0O1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MucG9zdChcbiAgICAgIHByb2Nlc3MuZW52LlJFQUNUX1BVQkxJQ19BUElfVVJMICsgJ2RlY3J5cHRpb24nLFxuICAgICAge1xuICAgICAgICBjaXBoZXJfdGV4dF9ibG9iLFxuICAgICAgICBlbmNyeXB0ZWRfZGF0YVxuICAgICAgfVxuICAgICk7XG5cbiAgICAvLyBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGF4aW9zLmdldChcbiAgICAvLyAgIHByb2Nlc3MuZW52LlJFQUNUX1BVQkxJQ19BUElfVVJMKydkZWNyeXB0JyxcbiAgICAvLyApO1xuICAgIHJldHVybiBkYXRhO1xuICB9LCBvcHRpb25zKTtcbn07XG4iXX0=