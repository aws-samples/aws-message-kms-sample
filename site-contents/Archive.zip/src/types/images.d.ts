declare module '*.webp';
declare module '*.png';
declare module "*.svg";