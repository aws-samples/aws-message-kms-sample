"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const decryption_1 = require("./decryption");
const encryption_1 = require("./encryption");
const home_1 = require("./home");
const routesData = [
    {
        path: "",
        element: <home_1.Home />,
        title: "home"
    },
    {
        path: "encryption",
        element: <encryption_1.Encryption />,
        title: "encryption"
    },
    {
        path: "decryption",
        element: <decryption_1.Decryption />,
        title: "decryption"
    },
];
exports.default = routesData;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVzLWRhdGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyb3V0ZXMtZGF0YS50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSw2Q0FBMEM7QUFDMUMsNkNBQTBDO0FBQzFDLGlDQUE4QjtBQUU5QixNQUFNLFVBQVUsR0FBaUI7SUFDL0I7UUFDRSxJQUFJLEVBQUUsRUFBRTtRQUNSLE9BQU8sRUFBRSxDQUFDLFdBQUksQ0FBQyxBQUFELEVBQUc7UUFDakIsS0FBSyxFQUFFLE1BQU07S0FDZDtJQUNEO1FBQ0UsSUFBSSxFQUFFLFlBQVk7UUFDbEIsT0FBTyxFQUFFLENBQUMsdUJBQVUsQ0FBQyxBQUFELEVBQUc7UUFDdkIsS0FBSyxFQUFFLFlBQVk7S0FDcEI7SUFDRDtRQUNFLElBQUksRUFBRSxZQUFZO1FBQ2xCLE9BQU8sRUFBRSxDQUFDLHVCQUFVLENBQUMsQUFBRCxFQUFHO1FBQ3ZCLEtBQUssRUFBRSxZQUFZO0tBQ3BCO0NBQ0YsQ0FBQztBQUVGLGtCQUFlLFVBQVUsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHJvdXRlclR5cGUgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBEZWNyeXB0aW9uIH0gZnJvbSAnLi9kZWNyeXB0aW9uJztcbmltcG9ydCB7IEVuY3J5cHRpb24gfSBmcm9tICcuL2VuY3J5cHRpb24nO1xuaW1wb3J0IHsgSG9tZSB9IGZyb20gJy4vaG9tZSc7XG5cbmNvbnN0IHJvdXRlc0RhdGE6IHJvdXRlclR5cGVbXSA9IFtcbiAge1xuICAgIHBhdGg6IFwiXCIsXG4gICAgZWxlbWVudDogPEhvbWUgLz4sXG4gICAgdGl0bGU6IFwiaG9tZVwiXG4gIH0sXG4gIHtcbiAgICBwYXRoOiBcImVuY3J5cHRpb25cIixcbiAgICBlbGVtZW50OiA8RW5jcnlwdGlvbiAvPixcbiAgICB0aXRsZTogXCJlbmNyeXB0aW9uXCJcbiAgfSxcbiAge1xuICAgIHBhdGg6IFwiZGVjcnlwdGlvblwiLFxuICAgIGVsZW1lbnQ6IDxEZWNyeXB0aW9uIC8+LFxuICAgIHRpdGxlOiBcImRlY3J5cHRpb25cIlxuICB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgcm91dGVzRGF0YTsiXX0=