declare const cipherTextBlobAtom: any;
export default cipherTextBlobAtom;
