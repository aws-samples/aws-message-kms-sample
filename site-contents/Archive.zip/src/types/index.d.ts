/// <reference types="react" />
export interface routerType {
    title: string;
    path: string;
    element: JSX.Element;
}
