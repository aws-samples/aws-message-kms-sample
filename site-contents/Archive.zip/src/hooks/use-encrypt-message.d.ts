interface EncryptMessageInput {
    keyId: string;
    message: string;
}
export declare const useEncryptMessage: (options: UseMutationOptions<unknown, unknown, EncryptMessageInput>) => any;
export {};
