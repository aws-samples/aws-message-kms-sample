import './style.css';
export declare const Home: () => any;
