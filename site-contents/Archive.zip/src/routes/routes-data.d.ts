import { routerType } from '../types';
declare const routesData: routerType[];
export default routesData;
