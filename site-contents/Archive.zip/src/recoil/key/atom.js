"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const recoil_1 = require("recoil");
const keyArnAtom = (0, recoil_1.atom)({
    key: 'keyArnAtom',
    default: '',
});
exports.default = keyArnAtom;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXRvbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImF0b20udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxtQ0FBNkI7QUFFN0IsTUFBTSxVQUFVLEdBQUcsSUFBQSxhQUFJLEVBQVM7SUFDOUIsR0FBRyxFQUFFLFlBQVk7SUFDakIsT0FBTyxFQUFFLEVBQUU7Q0FDWixDQUFDLENBQUE7QUFFRixrQkFBZSxVQUFVLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhdG9tIH0gZnJvbSAncmVjb2lsJ1xuXG5jb25zdCBrZXlBcm5BdG9tID0gYXRvbTxzdHJpbmc+KHtcbiAga2V5OiAna2V5QXJuQXRvbScsXG4gIGRlZmF1bHQ6ICcnLFxufSlcblxuZXhwb3J0IGRlZmF1bHQga2V5QXJuQXRvbTtcbiJdfQ==