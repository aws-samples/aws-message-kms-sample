export declare const Router: () => any;
