export declare const Encryption: () => any;
