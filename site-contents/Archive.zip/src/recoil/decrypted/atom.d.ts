declare const decryptedMessagesAtom: any;
export default decryptedMessagesAtom;
