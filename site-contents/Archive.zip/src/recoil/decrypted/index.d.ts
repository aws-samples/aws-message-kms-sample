import atom from './atom';
export default atom;
