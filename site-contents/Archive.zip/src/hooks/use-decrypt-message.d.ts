interface DecryptMessageInput {
    cipherTextBlob: string;
    encryptedData: string;
}
export declare const useDecryptMessage: (options: UseMutationOptions<unknown, unknown, DecryptMessageInput>) => any;
export {};
